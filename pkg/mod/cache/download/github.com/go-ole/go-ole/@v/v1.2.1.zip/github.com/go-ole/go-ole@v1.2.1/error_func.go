// +build !windows

package ole

// errstr converts error code to string.
func errstr(errno int) string {
	return ""
}
